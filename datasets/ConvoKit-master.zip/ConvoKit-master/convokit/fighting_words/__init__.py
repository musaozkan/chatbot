from .fightingWords import *

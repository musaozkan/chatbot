#!/usr/bin/env bash
rsync download_config.json $ZISSOU_USER@zissou.infosci.cornell.edu:/var/www/html/convokit/datasets/
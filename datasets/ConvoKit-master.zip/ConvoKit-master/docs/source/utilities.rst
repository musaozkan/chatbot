Utilities
---------

Miscellaneous utility functions for managing datasets

.. toctree::
   :maxdepth: 2

   Util <util.rst>
   Speaker Conversation Utilities <speaker_convo_helpers.rst>
   Pipeline <convokitPipeline.rst>

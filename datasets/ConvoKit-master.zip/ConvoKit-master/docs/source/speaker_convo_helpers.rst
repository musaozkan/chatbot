Speaker Conversation Utilities
==============================

Various helpers regarding aggregated speaker,conversation-level attributes. 

Example usage: `speaker conversation attributes <https://github.com/CornellNLP/ConvoKit/blob/master/examples/speaker-convo-attributes/speaker-convo-diversity-demo.ipynb>`_

.. automodule:: convokit.speaker_convo_helpers.speaker_convo_attrs
    :members:

.. automodule:: convokit.speaker_convo_helpers.speaker_convo_lifestage
	:members:



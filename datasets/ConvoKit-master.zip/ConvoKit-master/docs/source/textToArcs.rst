TextToArcs
==========

.. automodule:: convokit.text_processing.textToArcs
	:members:
VectorClassifier
================

Example usage: `bag-of-words classification <https://github.com/CornellNLP/ConvoKit/blob/master/examples/vectors/bag-of-words-demo.ipynb>`_.


.. automodule:: convokit.classifier.vectorClassifier
    :members:
    :inherited-members:

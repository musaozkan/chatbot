Transformer
============

.. automodule:: convokit.transformer
    :members:

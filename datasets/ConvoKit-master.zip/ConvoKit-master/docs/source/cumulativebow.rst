Cumulative Bag-of-Words Model
=============================

.. automodule:: convokit.forecaster.cumulativeBoW
    :members:
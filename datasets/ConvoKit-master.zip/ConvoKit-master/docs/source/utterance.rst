Utterance
=========

.. automodule:: convokit.model.utterance
    :members:
    :inherited-members:

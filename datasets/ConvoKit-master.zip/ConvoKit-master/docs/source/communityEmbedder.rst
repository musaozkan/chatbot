CommunityEmbedder
=================

.. automodule:: convokit.hyperconvo.communityEmbedder
    :members:

UtteranceNode
=============

.. automodule:: convokit.model.utteranceNode
    :members:

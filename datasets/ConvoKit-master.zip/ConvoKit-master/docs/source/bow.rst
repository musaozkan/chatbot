Bag-of-words Transformer
========================

.. automodule:: convokit.bag_of_words.bow_transformer
    :members:

Classifier
============

Example usage: `politeness classification <https://github.com/CornellNLP/ConvoKit/blob/master/examples/politeness-strategies/politeness_demo.ipynb>`_.

.. automodule:: convokit.classifier.classifier
    :members:

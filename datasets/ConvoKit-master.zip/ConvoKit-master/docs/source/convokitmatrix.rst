ConvoKitMatrix
==============

.. automodule:: convokit.model.convoKitMatrix
    :members:

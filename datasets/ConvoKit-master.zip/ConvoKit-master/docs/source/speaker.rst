Speaker
=======

.. automodule:: convokit.model.speaker
    :members:
    :inherited-members:

Pipeline
========

Supports pipelining ConvoKit transformers.

.. automodule:: convokit.convokitPipeline
	:members:
ThreadEmbedder
==============

.. automodule:: convokit.hyperconvo.threadEmbedder
    :members:

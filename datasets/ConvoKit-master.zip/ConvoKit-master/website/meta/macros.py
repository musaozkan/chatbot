# macro("example", lambda ctx: fetch(ctx, "site.title"))

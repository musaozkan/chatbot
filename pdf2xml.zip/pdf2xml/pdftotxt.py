from typing import Container
from io import BytesIO
from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer.converter import TextConverter, XMLConverter, HTMLConverter
from pdfminer.layout import LAParams
from pdfminer.pdfpage import PDFPage
import re

def convert_pdf(
    path: str,
    format: str = "text",
    codec: str = "utf-8",
    password: str = "",
    maxpages: int = 0,
    caching: bool = True,
    pagenos: Container[int] = set(),
) -> str:

    rsrcmgr = PDFResourceManager()
    retstr = BytesIO()
    laparams = LAParams()
    if format == "text":
        device = TextConverter(rsrcmgr, retstr, codec=codec, laparams=laparams)
    elif format == "html":
        device = HTMLConverter(rsrcmgr, retstr, codec=codec, laparams=laparams)
    elif format == "xml":
        device = XMLConverter(rsrcmgr, retstr, codec=codec, laparams=laparams)
    else:
        raise ValueError("provide format, either text, html or xml!")
    fp = open(path, "rb")
    interpreter = PDFPageInterpreter(rsrcmgr, device)
    print(f"Converting PDF file '{path}' to {format} format...")
    for page in PDFPage.get_pages(
        fp,
        pagenos,
        maxpages=maxpages,
        password=password,
        caching=caching,
        check_extractable=True,
    ):
        interpreter.process_page(page)
    text = retstr.getvalue().decode()
    fp.close()
    device.close()
    retstr.close()
    print(f"Conversion completed.")
    return text


# Example usage: convert "example.pdf" to plain text
pdf_content = convert_pdf("example.pdf")
# Convert to lowercase
pdf_content = pdf_content.lower()
# Replace multiple newlines with a single newline
pdf_content = re.sub(r'\n+', '\n', pdf_content)
# Replace multiple spaces with a single space
pdf_content = re.sub(r'\s{2,}', ' ', pdf_content)
# Remove footnote references
pdf_content = re.sub(r'\[[0-9]+\]', '', pdf_content)
# Remove stop words
pdf_content = re.sub(r'\b(the|and|a)\b', '', pdf_content)
with open('output.txt', 'w', encoding='utf-8') as file:
    file.write(pdf_content)


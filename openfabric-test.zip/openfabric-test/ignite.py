from openfabric_pysdk.starter import OpenfabricStarter

if __name__ == '__main__':
    OpenfabricStarter.ignite(debug=False, host="0.0.0.0", port=5000),
